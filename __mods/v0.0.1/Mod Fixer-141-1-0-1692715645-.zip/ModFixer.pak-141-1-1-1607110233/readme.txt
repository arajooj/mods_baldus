#Mod Fixer

This pak forces the story to recompile, allowing pak mods to work with BG3.

All credit for this technique goes to Norbyte!

## Installation

Just place the .pak file into your `%LocalAppdata%\Larian Studios\Baldur's Gate 3\Mods` folder.
Or install via Vortex
That's it.