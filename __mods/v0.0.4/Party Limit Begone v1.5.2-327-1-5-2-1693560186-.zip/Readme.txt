Installation:
1. Download and unzip this mod.
2. Move the whole Mods folder in to your Baldurs Gate 3 Data folder. That's the game folder, not appdata.
3. Drag and drop either your bg3.exe or bg3_dx11.exe onto the PartyLimitBegonePatcher.bat file. It will create a backup for you.
4. That's it, enjoy the game!

If you don't want to increase the multiplayer limit just move the mods folder into your data folder, you don't have to patch your exe files.
Not working? It shouldn't be required but some users only got it to work by using the mod fixer: https://www.nexusmods.com/baldursgate3/mods/550
The PatchFiles folder and PartyLimitBegonePatcher.bat can be deleted after you patched your files. You obviously have to reapply the patch after a game update. Maybe make a manual backup before doing so just in case something changed and the patch needs to be updated.

Uninstall:
1. Delete the patched exe file and restore your backup.
2. Delete the Mods folder inside your Data folder, that's it.

Important:
In order to continue your multiplayer save with more than 4 players, create a new lobby, set your party size and start a new game. Then load your main save, this will carry over the player limit. Ingame sessions unfortunately don't allow you to tweak the settings.
You must dismiss one party member if you already have 4 with you, this will reset the party limit and set it to 16.
The larian game launcher will throw a data mismatch warning at you, that's completly normal and can safely be ignored.
Some ingame events are hardcoded for 4 party members and will glitch out. This is usually solved by either dismissing the additional members/players or by teleporting back and forth.

Known issues and workarounds, thread in the bug section:
Camp sleeping bug: Use one of the awake companions and talk to Lae'zel or reduce your party size to 4 before resting.
Grymforge Map transition: Reduce your party size to 4 members before sailing with the boat. If you already used it and your characters are stuck, dismiss the ones that are with you and sail back and forth to unstuck the rest. 
Note: After using the boat a timed quest is triggered and going to camp will progess it.
Credits to amlw from the BG3 discord for finding the hardcoded multiplayer bits.

Mod by Sildur:
https://www.nexusmods.com/baldursgate3/mods/327
